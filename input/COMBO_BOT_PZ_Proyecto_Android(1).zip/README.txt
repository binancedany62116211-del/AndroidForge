COMBO BOT PZ - proyecto Android base

Nombre: COMBO BOT PZ
Paquete: com.combobotpz
Contenido: simulador educativo DCA/GRID que funciona sin conexión dentro de WebView.

IMPORTANTE:
- Este ZIP contiene el código fuente del proyecto Android; NO es un APK ya compilado.
- Para obtener el APK, abre/importa esta carpeta en Android Studio y compila el módulo app.
- Este bot es únicamente un simulador con precios aleatorios y saldo ficticio.
- No incluye conexión a exchanges ni ejecuta operaciones reales.
